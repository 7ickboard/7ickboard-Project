//
//  ViewController.swift
//  7ickboard
//
//  Created by Kinam on 4/22/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

